public class JavaZonApp
{
	public static void main(String[] args)
	{
		JavaZonFrame inst = new JavaZonFrame();
		inst.setLocationRelativeTo(null);
		inst.setVisible(true);
	}
}
